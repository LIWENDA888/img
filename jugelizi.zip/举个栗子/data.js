// 导航网站数据配置
const navData = {
    '包装': {
        icon: 'package',
        groups: {
            '国内': [
                { title: '古田路9号', desc: '国内顶尖包装与品牌社区，丰富的实体产品包装案例。', img: 'https://images.unsplash.com/photo-1605648813351-54b3e343cc77?w=300&h=300&fit=crop', tags: ['实体', '品牌', '印刷'], url: 'https://www.gtn9.com' },
                { title: '普象网', desc: '聚集工业设计及包装设计的创意分享社区。', img: 'https://images.unsplash.com/photo-1561070791-2526d30994b5?w=300&h=300&fit=crop', tags: ['工业设计', '创意', '产品'], url: 'https://www.puxiang.com' }
            ],
            '国外': [
                { title: 'The Dieline', desc: '全球包装设计大奖作品库与行业前沿资讯。', img: 'https://images.unsplash.com/photo-1549465220-1a8b9238cd48?w=300&h=300&fit=crop', tags: ['大奖', '前沿', '快消品'], url: 'https://thedieline.com' },
                { title: 'Packaging of the World', desc: '每日更新世界各地最具创意的包装设计案例。', img: 'https://images.unsplash.com/photo-1611162617474-5b21e879e113?w=300&h=300&fit=crop', tags: ['灵感库', '全球分享'], url: 'https://packagingoftheworld.com' }
            ]
        }
    },
    '品牌': {
        icon: 'style',
        groups: {
            '国内': [
                { title: '标志情报局', desc: '提供最新的标志设计资讯、品牌升级全案分析与洞察。', img: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=300&h=300&fit=crop', tags: ['Logo', '全案资讯'], url: 'https://www.logonews.cn' },
                { title: '品牌几何', desc: '营销人的学习成长社区，深度剖析品牌构建与传播。', img: 'https://images.unsplash.com/photo-1512941937669-90a1b58e7e9c?w=300&h=300&fit=crop', tags: ['营销分析', '策略'], url: 'https://www.brandprousa.com' } // 仅占位演示
            ],
            '国外': [
                { title: 'Brand New', desc: '最知名的品牌形象重塑与标志设计专业点评博客。', img: 'https://images.unsplash.com/photo-1558655146-d09347e92766?w=300&h=300&fit=crop', tags: ['重塑', '标志', '点评'], url: 'https://www.underconsideration.com/brandnew/' },
                { title: 'Logo Design Love', desc: '关于标志与品牌形象设计的深度剖析独立博客网站。', img: 'https://images.unsplash.com/photo-1587613990444-cbd5fb79f045?w=300&h=300&fit=crop', tags: ['经典', '标志'], url: 'https://www.logodesignlove.com' }
            ]
        }
    },
    'UI': {
        icon: 'layers',
        groups: {
            '国内': [
                { title: 'UI中国', desc: '专业的用户体验设计平台，中国具有影响力的设计社区。', img: 'https://images.unsplash.com/photo-1611162617474-5b21e879e113?w=300&h=300&fit=crop', tags: ['UI/UX', '社区', '文章'], url: 'https://www.ui.cn' },
                { title: '站酷 ZCOOL', desc: '综合性设计创意社区，聚集百万设计师，发现更好的设计。', img: 'https://images.unsplash.com/photo-1561070791-2526d30994b5?w=300&h=300&fit=crop', tags: ['综合', '插画', '作品集'], url: 'https://www.zcool.com.cn' },
                { title: '蓝湖', desc: '高效的产品设计协作平台，无缝衔接设计与研发。', img: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=300&h=300&fit=crop', tags: ['协作', '交付', '工具'], url: 'https://lanhuapp.com' },
                { title: '即时设计', desc: '可云端编辑的专业级 UI 设计工具，为中国设计师量身打造。', img: 'https://images.unsplash.com/photo-1558655146-d09347e92766?w=300&h=300&fit=crop', tags: ['设计工具', '云端', '协作'], url: 'https://js.design' },
                { title: 'Pixso', desc: '新一代设计协作工具，打通产设研团队的一站式工作。', img: 'https://images.unsplash.com/photo-1512941937669-90a1b58e7e9c?w=300&h=300&fit=crop', tags: ['UI/UX', '在线工具'], url: 'https://pixso.cn' },
                { title: '优设网', desc: '优秀网页设计联盟，国内极具人气的设计师学习平台。', img: 'https://images.unsplash.com/photo-1587613990444-cbd5fb79f045?w=300&h=300&fit=crop', tags: ['教程', '文章', '灵感'], url: 'https://www.uisdc.com' }
            ],
            '国外': [
                { title: 'Dribbble', desc: '全球顶级设计师展示舞台，寻找最新的设计趋势与创意灵感。', img: 'https://images.unsplash.com/photo-1587613990444-cbd5fb79f045?w=300&h=300&fit=crop', tags: ['全球', '前沿', '动效'], url: 'https://dribbble.com' },
                { title: 'Figma Community', desc: '全球最大的设计开源社区，海量插件、组件与系统开源库。', img: 'https://images.unsplash.com/photo-1611162616475-46b635cb6868?w=300&h=300&fit=crop', tags: ['源文件', '组件', '插件'], url: 'https://www.figma.com/community' },
                { title: 'Mobbin', desc: '超好用的真实 App 交互界面与截图参考工具，覆盖各类分类。', img: 'https://images.unsplash.com/photo-1512941937669-90a1b58e7e9c?w=300&h=300&fit=crop', tags: ['移动端', '交互', '截图'], url: 'https://mobbin.com' },
                { title: 'Behance', desc: 'Adobe旗下的综合创意作品展示平台。', img: 'https://images.unsplash.com/photo-1558655146-d09347e92766?w=300&h=300&fit=crop', tags: ['综合', '排版', '概念'], url: 'https://www.behance.net' },
                { title: 'Awwwards', desc: '表彰来自世界各地的最优秀网页设计和开发。', img: 'https://images.unsplash.com/photo-1550684376-efcbd6e3f031?w=300&h=300&fit=crop', tags: ['大奖', '网页', '前沿'], url: 'https://www.awwwards.com' },
                { title: 'UI8', desc: '优质设计资源聚合地，提供海量图标、UI套件与3D素材。', img: 'https://images.unsplash.com/photo-1549465220-1a8b9238cd48?w=300&h=300&fit=crop', tags: ['优质素材', '3D', '组件库'], url: 'https://ui8.net' }
            ]
        }
    },
    '广告': {
        icon: 'campaign',
        groups: {
            '国内': [
                { title: '数英网 Digitaling', desc: '大中华区权威的数字媒体及职业招聘平台，收集海量创意文案。', img: 'https://images.unsplash.com/photo-1550684376-efcbd6e3f031?w=300&h=300&fit=crop', tags: ['文案', '公关', '营销'], url: 'https://www.digitaling.com' },
                { title: '梅花网', desc: '聚焦营销领域的资讯门户，提供国内外实战广告营销案例。', img: 'https://images.unsplash.com/photo-1605648813351-54b3e343cc77?w=300&h=300&fit=crop', tags: ['公关策略', '营销推广'], url: 'https://www.meihua.info' }
            ],
            '国外': [
                { title: 'Ads of the World', desc: '全球最大的广告创意作品库与广告视频聚合网。', img: 'https://images.unsplash.com/photo-1611162616475-46b635cb6868?w=300&h=300&fit=crop', tags: ['视频', '平面', '全球'], url: 'https://www.adsoftheworld.com' }
            ]
        }
    },
    'LOGO': {
        icon: 'interests',
        groups: {
            '国内': [
                { title: '数英网 Digitaling', desc: '大中华区权威的数字媒体及职业招聘平台，收集海量创意文案。', img: 'https://images.unsplash.com/photo-1550684376-efcbd6e3f031?w=300&h=300&fit=crop', tags: ['文案', '公关', '营销'], url: 'https://www.digitaling.com' },
                { title: '梅花网', desc: '聚焦营销领域的资讯门户，提供国内外实战广告营销案例。', img: 'https://images.unsplash.com/photo-1605648813351-54b3e343cc77?w=300&h=300&fit=crop', tags: ['公关策略', '营销推广'], url: 'https://www.meihua.info' }
            ],
            '国外': [
                { title: 'Ads of the World', desc: '全球最大的广告创意作品库与广告视频聚合网。', img: 'https://images.unsplash.com/photo-1611162616475-46b635cb6868?w=300&h=300&fit=crop', tags: ['视频', '平面', '全球'], url: 'https://www.adsoftheworld.com' }
            ]
        }
    },
    '字体': {
        icon: 'text_fields',
        groups: {
            '国内': [
                { title: '数英网 Digitaling', desc: '大中华区权威的数字媒体及职业招聘平台，收集海量创意文案。', img: 'https://images.unsplash.com/photo-1550684376-efcbd6e3f031?w=300&h=300&fit=crop', tags: ['文案', '公关', '营销'], url: 'https://www.digitaling.com' },
                { title: '梅花网', desc: '聚焦营销领域的资讯门户，提供国内外实战广告营销案例。', img: 'https://images.unsplash.com/photo-1605648813351-54b3e343cc77?w=300&h=300&fit=crop', tags: ['公关策略', '营销推广'], url: 'https://www.meihua.info' }
            ],
            '国外': [
                { title: 'Ads of the World', desc: '全球最大的广告创意作品库与广告视频聚合网。', img: 'https://images.unsplash.com/photo-1611162616475-46b635cb6868?w=300&h=300&fit=crop', tags: ['视频', '平面', '全球'], url: 'https://www.adsoftheworld.com' }
            ]
        }
    },
    '排版': {
        icon: 'grid_view',
        groups: {
            '国内': [
                { title: '数英网 Digitaling', desc: '大中华区权威的数字媒体及职业招聘平台，收集海量创意文案。', img: 'https://images.unsplash.com/photo-1550684376-efcbd6e3f031?w=300&h=300&fit=crop', tags: ['文案', '公关', '营销'], url: 'https://www.digitaling.com' },
                { title: '梅花网', desc: '聚焦营销领域的资讯门户，提供国内外实战广告营销案例。', img: 'https://images.unsplash.com/photo-1605648813351-54b3e343cc77?w=300&h=300&fit=crop', tags: ['公关策略', '营销推广'], url: 'https://www.meihua.info' }
            ],
            '国外': [
                { title: 'Ads of the World', desc: '全球最大的广告创意作品库与广告视频聚合网。', img: 'https://images.unsplash.com/photo-1611162616475-46b635cb6868?w=300&h=300&fit=crop', tags: ['视频', '平面', '全球'], url: 'https://www.adsoftheworld.com' }
            ]
        }
    },
    '配色': {
        icon: 'palette',
        groups: {
            '国内': [
                { title: '中国色', desc: '传统中国色彩美学库，提供精准 CMYK 与 RGB 色值。', img: 'https://images.unsplash.com/photo-1505909182942-e2f09aee3e89?w=300&h=300&fit=crop', tags: ['传统', '色板', '国风'], url: 'http://zhongguose.com' },
                { title: '优设配色', desc: '精选大量优质网页配色和渐变色工具，即点即用。', img: 'https://images.unsplash.com/photo-1561070791-2526d30994b5?w=300&h=300&fit=crop', tags: ['聚合导航', '即点即用'], url: 'https://color.uisdc.com' }
            ],
            '国外': [
                { title: 'Adobe Color', desc: '专业的调色盘生成工具，支持色轮与提取图片颜色。', img: 'https://images.unsplash.com/photo-1549465220-1a8b9238cd48?w=300&h=300&fit=crop', tags: ['工具', '色轮', '高阶'], url: 'https://color.adobe.com' },
                { title: 'Coolors', desc: '超快速的配色方案生成器，按下空格即可无限刷新。', img: 'https://images.unsplash.com/photo-1512941937669-90a1b58e7e9c?w=300&h=300&fit=crop', tags: ['快捷生成', '色板'], url: 'https://coolors.co' },
                { title: 'Color Hunt', desc: '一个开放式的调色板分享平台，适合寻找现成灵感。', img: 'https://images.unsplash.com/photo-1558655146-d09347e92766?w=300&h=300&fit=crop', tags: ['流行', '精选色板'], url: 'https://colorhunt.co' }
            ]
        }
    }
};